package com.example.assetstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.assetstore.model.StoreDetails;

public interface StoreRepository extends JpaRepository<StoreDetails, Long> {

}
