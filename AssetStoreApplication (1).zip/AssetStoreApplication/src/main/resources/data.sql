insert into asset_details(id,assetname)values(1001,'laptop'),(1002,'mobile');
insert into store_details(storeid,storevalue, as_fk)values(2001,30000,1001),(2002,40000,1001),(2003,50000,1002);
insert into roles (name)values('ROLE_USER'),('ROLE_ADMIN');
insert into users(email,name,password,username)values('sap@gmail.com','sapthami','$2a$10$CuuwpSlf0TCS9p8AcZqKROeZjqxX7JQqchDXk1dD.ahNk1xATnGTy','sap'),('admin@gmail.com','admin','$2a$10$8W8k8zwd.BKcp/ARAJXbMeBINeRx1qziBuRhwXi0e9mxSrFSa.8e.','Admin');
insert into user_roles(user_id,role_id)values(1,1),(2,2);