package com.example.assetstore.AssetTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.example.assetstore.dao.AssetService;
import com.example.assetstore.model.AssetDetails;
import com.example.assetstore.model.StoreDetails;
import com.example.assetstore.repository.AssetRepository;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class AssetStoreTests {
	@Mock
	private AssetRepository assetrep;
   
	@InjectMocks
	private AssetService assetserv;
	
	private AssetDetails assetdet;
		
	private AssetDetails assetdet1;
		
	@BeforeEach
	public void setup() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1=sdf.parse("2022-04-05");
		
		List<StoreDetails> store=new ArrayList<StoreDetails>();
		StoreDetails storedet=new StoreDetails(2001,60000, yourDate, yourDate1);
	    StoreDetails sto=new StoreDetails(2002,70000, yourDate, yourDate1);
		store.add(storedet);
	    store.add(sto);
	    
		assetdet=AssetDetails.builder()
				             .id(1001L)
				             .assetname("DeLLLaptop")
				             .storedetails(store)
				             .createddate(yourDate)
				             .modifieddate(yourDate1)
				             .build();
		 assetdet1=AssetDetails.builder()
	             .id(1002L)
	             .assetname("SamsungMobile")
	             .storedetails(store)
	             .createddate(yourDate)
	             .modifieddate(yourDate1)
	             .build();
	}	
	@Test
	public void addAssetDetailsTest() {
		given(assetrep.save(assetdet)).willReturn(assetdet);
		AssetDetails savedasset=assetserv.addAssetDetails(assetdet);
		assertThat(savedasset).isNotNull();
		
	}
	
	@Test
	
	public void getAllAssetTest() {
		given(assetrep.findAll()).willReturn(List.of(assetdet,assetdet1));
		List<AssetDetails> assetlist=assetserv.getAllAsset();
	//	assertThat(assetlist).isNotNull();
		assertThat(assetlist.size()).isEqualTo(2);
		
		
	}
	
	@Test
	
	public void getAssetByIdTest() {
		
		given(assetrep.findById(1001L)).willReturn(Optional.of(assetdet));
		AssetDetails foundasset=assetserv.getAssetById(assetdet.getId()).get();
		assertThat(foundasset).isNotNull();
		
	}
	
	@Test
	
     public void updateAssetTest() {
       given(assetrep.getById(1002L)).willReturn(assetdet1);
       assetdet1.setAssetname("HeadPhone");
       given(assetrep.save(assetdet1)).willReturn(assetdet1);
       AssetDetails assetdet3=assetserv.updateAssetStore(assetdet1);
       assertThat(assetdet3).isEqualTo(assetdet1);
       
		
		
	}
	
	@Test
	public void deleteAssetTest() {
		 long assetId=1001L;
		 willDoNothing().given(assetrep).deleteById(assetId);
		 assetserv.deleteAsset(assetId);
		 verify(assetrep,times(1)).deleteById(assetId);
	}
	
	

}
